
import React, { useState } from 'react';
import { Slide } from '../types';

export const SlideDeck: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides: Slide[] = [
    {
      id: 1,
      section: "INTRO",
      title: "GROWTH MASTERY",
      theme: "dark",
      content: (
        <div className="text-center space-y-6">
          <div className="text-6xl font-black tracking-tighter mb-4 animate-pulse">DESIGN YOUR LIFE</div>
          <div className="text-3xl font-light text-emerald-400">ออกแบบชีวิต ปลุกพลังลงมือทำ</div>
          <div className="pt-12">
            <div className="h-1 w-24 bg-emerald-500 mx-auto mb-4"></div>
            <p className="text-xl">โดย ครูเด่น มาสเตอร์ ฟา</p>
          </div>
        </div>
      )
    },
    {
      id: 2,
      section: "CHECK-IN",
      title: "How is your energy?",
      theme: "orange",
      content: (
        <div className="grid grid-cols-2 gap-12 items-center h-full">
          <div className="space-y-6">
            <p className="text-2xl leading-relaxed">ก่อนเราจะเริ่มออกแบบชีวิต...</p>
            <p className="text-4xl font-bold">วันนี้ใจของคุณพร้อมเติบโตระดับไหน? (10-100%)</p>
          </div>
          <div className="flex justify-center">
            <div className="w-48 h-80 border-4 border-white rounded-3xl p-2 relative overflow-hidden">
               <div className="absolute bottom-0 left-0 w-full bg-orange-400 animate-bounce" style={{ height: '75%' }}></div>
               <div className="relative z-10 flex items-center justify-center h-full text-4xl font-black">75%</div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 3,
      section: "MINDSET",
      title: "Why Growth Mindset?",
      theme: "blue",
      content: (
        <div className="space-y-8">
          <ul className="space-y-6 text-2xl">
            <li className="flex items-start">
              <span className="bg-white text-blue-600 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0 text-sm font-bold">1</span>
              <span>โลกเปลี่ยนไว - ความรู้เดิมหมดอายุเร็ว</span>
            </li>
            <li className="flex items-start">
              <span className="bg-white text-blue-600 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0 text-sm font-bold">2</span>
              <span>ทีมจะแกร่ง - คนต้อง "เก่งขึ้น" จากภายใน</span>
            </li>
            <li className="flex items-start">
              <span className="bg-white text-blue-600 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0 text-sm font-bold">3</span>
              <span className="font-bold">"ความล้มเหลว ไม่ใช่ทางตัน แต่เป็นบันได"</span>
            </li>
          </ul>
        </div>
      )
    },
    {
      id: 4,
      section: "MINDSET",
      title: "Fixed vs. Growth Mindset",
      theme: "dark",
      content: (
        <div className="grid grid-cols-2 gap-8 h-full">
          <div className="bg-red-900/20 p-8 rounded-2xl border border-red-500/30">
            <h3 className="text-red-400 font-bold text-2xl mb-6">FIXED MINDSET</h3>
            <ul className="space-y-4 italic opacity-70">
              <li>"ฉันทำไม่ได้หรอก"</li>
              <li>"เขามีพรสวรรค์ ฉันไม่มี"</li>
              <li>"ยากเกินไป เสียเวลา"</li>
            </ul>
          </div>
          <div className="bg-emerald-900/20 p-8 rounded-2xl border border-emerald-500/30">
            <h3 className="text-emerald-400 font-bold text-2xl mb-6">GROWTH MINDSET</h3>
            <ul className="space-y-4">
              <li>"ฉันเรียนรู้และฝึกฝนได้"</li>
              <li>"ความพยายามทำให้เก่งขึ้น"</li>
              <li>"นี่คือโอกาสที่จะท้าทายตัวเอง"</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 5,
      section: "ACTIVITY",
      title: "ACTIVITY: Flip the Switch",
      theme: "orange",
      content: (
        <div className="text-center space-y-8">
          <p className="text-3xl">มาสลับสวิตช์ความคิดกันเถอะ!</p>
          <div className="flex justify-center space-x-12">
            <div className="bg-white/10 p-6 rounded-xl w-64 border border-dashed">เขียนสิ่งที่ฉุดรั้งคุณ</div>
            <div className="text-4xl flex items-center">➡️</div>
            <div className="bg-white/10 p-6 rounded-xl w-64 border border-dashed">ขยำทิ้ง แล้วเขียนใหม่!</div>
          </div>
          <p className="text-lg opacity-80">เปลี่ยนจากภาษาลบ เป็น "ภาษาแห่งการเติบโต"</p>
        </div>
      )
    },
    {
      id: 6,
      section: "SELF-MANAGEMENT",
      title: "3 ทักษะจัดการใจ",
      theme: "emerald",
      content: (
        <div className="grid grid-cols-3 gap-6 h-full">
          {[
            { t: "Awareness", d: "รู้ทันอารมณ์ที่กำลังเกิดขึ้น" },
            { t: "Pause", d: "S.T.O.P หยุดหายใจก่อนโต้ตอบ" },
            { t: "Reframing", d: "มองหามุมบวกหรือบทเรียนใหม่" }
          ].map((item, i) => (
            <div key={i} className="bg-white text-emerald-900 p-8 rounded-2xl shadow-xl flex flex-col justify-center text-center">
              <div className="text-4xl mb-4 font-black">{i+1}</div>
              <div className="text-2xl font-bold mb-2">{item.t}</div>
              <div className="text-sm opacity-80">{item.d}</div>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 7,
      section: "LIFE PLANNING",
      title: "สมดุลชีวิตคือความยั่งยืน",
      theme: "blue",
      content: (
        <div className="flex items-center space-x-12 h-full">
          <div className="w-1/2 space-y-6">
             <div className="p-6 bg-white/10 rounded-xl border-l-4 border-white">
               "งานรุ่ง แต่สุขภาพร่วง = ไม่คุ้ม"
             </div>
             <div className="p-6 bg-white/10 rounded-xl border-l-4 border-white">
               "เงินดี แต่ไม่มีครอบครัว = ว่างเปล่า"
             </div>
          </div>
          <div className="w-1/2 text-3xl font-bold leading-snug">ถึงเวลา... เช็คสภาพ "วงล้อชีวิต" ของคุณ</div>
        </div>
      )
    },
    {
      id: 8,
      section: "LIFE PLANNING",
      title: "Wheel of Life Assessment",
      theme: "blue",
      content: (
        <div className="grid grid-cols-4 gap-4">
          {["การงาน", "การเงิน", "สุขภาพ", "ครอบครัว", "ความรัก", "พัฒนาตนเอง", "พักผ่อน", "การแบ่งปัน"].map((item, i) => (
            <div key={i} className="bg-white/20 p-4 rounded-lg text-center font-bold">{item}</div>
          ))}
          <div className="col-span-4 mt-6 text-center text-xl font-light italic">สำรวจทั้ง 8 ด้านเพื่อหา "จุดบอด" ของชีวิต</div>
        </div>
      )
    },
    {
      id: 9,
      section: "WORKSHEET TIME",
      title: "ACTIVITY: Draw Your Wheel",
      theme: "orange",
      content: (
        <div className="text-center space-y-12">
           <div className="text-4xl font-bold">เชิญใช้ใบงานที่ 1: THE WHEEL OF HARMONY</div>
           <div className="flex justify-center items-center space-x-8">
              <div className="text-2xl bg-white text-orange-600 w-16 h-16 rounded-full flex items-center justify-center font-bold">1</div>
              <div className="text-xl">ให้คะแนน 1-10 ในแต่ละด้าน</div>
              <div className="text-2xl">➡️</div>
              <div className="text-2xl bg-white text-orange-600 w-16 h-16 rounded-full flex items-center justify-center font-bold">2</div>
              <div className="text-xl">ลากเส้นเชื่อมเพื่อดู "รูปร่าง" ของชีวิต</div>
           </div>
        </div>
      )
    },
    {
      id: 10,
      section: "REFLECTION",
      title: "Reflection: ชวนคิดสะกิดใจ",
      theme: "dark",
      content: (
        <div className="space-y-12">
          <div className="flex items-center space-x-6">
            <div className="text-5xl opacity-30 italic">"</div>
            <p className="text-2xl">ด้านไหนที่คุณละเลยมานานที่สุด?</p>
          </div>
          <div className="flex items-center space-x-6">
            <div className="text-5xl opacity-30 italic">"</div>
            <p className="text-2xl text-emerald-400 font-bold">ด้านไหนที่ถ้าดีขึ้น... จะส่งผลดีต่อด้านอื่นๆ ทั้งหมด?</p>
          </div>
        </div>
      )
    },
    {
      id: 11,
      section: "STRATEGY",
      title: "Design Your Future (Life Design)",
      theme: "emerald",
      content: (
        <div className="text-center space-y-8">
          <h3 className="text-3xl font-light">เลือก 1 ด้านที่ต้องการโฟกัสใน 3 เดือนนี้</h3>
          <div className="bg-white text-emerald-900 p-12 rounded-3xl shadow-2xl inline-block">
            <p className="text-5xl font-black">เป้าหมายคืออะไร?</p>
            <p className="mt-4 opacity-60 text-xl">(Specific Goal)</p>
          </div>
        </div>
      )
    },
    {
      id: 12,
      section: "STRATEGY",
      title: "Vision Board: ภาพความสำเร็จ",
      theme: "emerald",
      content: (
        <div className="grid grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-2xl">จินตนาการถึงวันที่คุณทำสำเร็จ...</p>
            <ul className="space-y-2 opacity-80 list-disc list-inside">
              <li>คุณรู้สึกอย่างไร?</li>
              <li>ใครอยู่ข้างๆ คุณ?</li>
              <li>คุณกำลังทำอะไรอยู่?</li>
            </ul>
          </div>
          <div className="bg-gray-200 aspect-video rounded-xl flex items-center justify-center text-gray-400 font-bold italic border-4 border-dashed">
            [ภาพจำลอง Vision Board]
          </div>
        </div>
      )
    },
    {
      id: 13,
      section: "ACTION",
      title: "The Gap: ความฝัน vs ความจริง",
      theme: "dark",
      content: (
        <div className="text-center h-full flex flex-col justify-center space-y-8">
           <div className="text-7xl font-black text-red-500">GAP</div>
           <p className="text-3xl">ถมได้ด้วยสิ่งเดียวคือ... "การลงมือทำ" (Action)</p>
           <p className="text-sm opacity-50 italic">ศัตรูคือ "ความสมบูรณ์แบบ" และ "การผัดวันประกันพรุ่ง"</p>
        </div>
      )
    },
    {
      id: 14,
      section: "ACTION",
      title: "The 1% Rule",
      theme: "blue",
      content: (
        <div className="grid grid-cols-2 gap-12 items-center">
           <div className="text-center">
              <div className="text-8xl font-black">1%</div>
              <p className="text-2xl mt-4">Small Wins matter.</p>
           </div>
           <div className="space-y-4 text-xl">
              <p>ดีขึ้นวันละ 1% ครบ 1 ปี...</p>
              <p className="text-4xl font-bold text-yellow-400">คุณจะดีขึ้น 37 เท่า!</p>
              <p className="text-sm opacity-70">"ไม่ต้องเปลี่ยนโลกในข้ามคืน แค่ก้าวต่อก้าว"</p>
           </div>
        </div>
      )
    },
    {
      id: 15,
      section: "ACTION",
      title: "Micro-Habits: นิสัยเล็กๆ",
      theme: "emerald",
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-6">
            <div className="bg-emerald-800/30 p-6 rounded-xl">
               <div className="font-bold mb-2">สุขภาพ</div>
               <p className="text-sm opacity-70">ดื่มน้ำเพิ่ม 1 แก้ว/วัน</p>
            </div>
            <div className="bg-emerald-800/30 p-6 rounded-xl">
               <div className="font-bold mb-2">พัฒนาตนเอง</div>
               <p className="text-sm opacity-70">อ่านหนังสือวันละ 2 หน้า</p>
            </div>
            <div className="bg-emerald-800/30 p-6 rounded-xl">
               <div className="font-bold mb-2">การเงิน</div>
               <p className="text-sm opacity-70">หยอดกระปุกวันละ 20 บาท</p>
            </div>
          </div>
          <p className="text-center mt-12 text-2xl font-bold">ทำง่ายจนคุณ "ปฏิเสธไม่ได้"</p>
        </div>
      )
    },
    {
      id: 16,
      section: "WORKSHEET TIME",
      title: "ACTIVITY: Growth Roadmap",
      theme: "emerald",
      content: (
        <div className="text-center space-y-8">
          <p className="text-3xl font-bold">เชิญใช้ใบงานที่ 2: MY GROWTH ROADMAP</p>
          <div className="flex justify-center space-x-12">
            <div className="border border-white/30 p-6 rounded-xl w-64">วิเคราะห์ตนเองวันนี้</div>
            <div className="border border-white/30 p-6 rounded-xl w-64">วางแผน Action 90 วัน</div>
            <div className="border border-white/30 p-6 rounded-xl w-64">เขียนคำมั่นสัญญา 1%</div>
          </div>
        </div>
      )
    },
    {
      id: 17,
      section: "CHALLENGE",
      title: "Overcoming Obstacles",
      theme: "dark",
      content: (
        <div className="space-y-12">
           <h3 className="text-3xl text-center">เมื่อเจออุปสรรค... ให้ถามว่า</h3>
           <div className="grid grid-cols-2 gap-12">
              <div className="bg-white/10 p-8 rounded-2xl border-l-8 border-emerald-500">
                 "เรื่องนี้สอนอะไรฉัน?"
              </div>
              <div className="bg-white/10 p-8 rounded-2xl border-l-8 border-orange-500">
                 "มีวิธีไหนที่สนุกกว่าเดิม?"
              </div>
           </div>
        </div>
      )
    },
    {
      id: 18,
      section: "COMMITMENT",
      title: "พันธสัญญาแห่งนักปฏิบัติ",
      theme: "orange",
      content: (
        <div className="text-center space-y-12">
           <p className="text-3xl italic">"ความสำเร็จคือผลลัพธ์ของระเบียบวินัย"</p>
           <div className="bg-white text-orange-900 p-12 rounded-full inline-block animate-pulse">
              <p className="text-4xl font-bold">บอกเป้าหมายกับ Buddy</p>
           </div>
           <p className="text-xl">สัญญาว่าจะติดตามผลกันใน 1 สัปดาห์</p>
        </div>
      )
    },
    {
      id: 19,
      section: "Q&A",
      title: "แลกเปลี่ยนเรียนรู้ (Sharing)",
      theme: "dark",
      content: (
        <div className="text-center h-full flex flex-col justify-center space-y-12">
           <div className="text-8xl">?</div>
           <p className="text-3xl">คำถามหรือสิ่งที่อยากแบ่งปัน?</p>
        </div>
      )
    },
    {
      id: 20,
      section: "CLOSING",
      title: "The Future is in Your Hands",
      theme: "dark",
      content: (
        <div className="text-center space-y-12">
           <p className="text-3xl leading-relaxed italic">
             "The best way to predict the future is to create it."
           </p>
           <div className="h-1 w-32 bg-emerald-500 mx-auto"></div>
           <div>
              <p className="text-2xl font-bold">ขอบคุณและสวัสดีครับ</p>
              <p className="opacity-50 mt-2">Kru Den Master Fa | Art of Growth</p>
           </div>
        </div>
      )
    }
  ];

  const next = () => setCurrentSlide(prev => Math.min(slides.length - 1, prev + 1));
  const prev = () => setCurrentSlide(prev => Math.max(0, prev - 1));

  const themeClasses = {
    blue: "bg-blue-600 text-white",
    emerald: "bg-emerald-600 text-white",
    orange: "bg-orange-500 text-white",
    dark: "bg-gray-900 text-white"
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Slide Viewport */}
      <div className={`relative w-full aspect-video rounded-3xl shadow-2xl overflow-hidden mb-8 transition-all duration-500 printable-slide ${themeClasses[slides[currentSlide].theme]}`}>
        {/* Background Decor */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-bl-full pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-black opacity-5 rounded-tr-full pointer-events-none"></div>

        {/* Slide Content */}
        <div className="h-full p-16 flex flex-col">
          <header className="flex justify-between items-start mb-12">
            <div>
               <p className="text-sm font-black uppercase tracking-widest opacity-60">{slides[currentSlide].section}</p>
               <h2 className="text-4xl font-black tracking-tight">{slides[currentSlide].title}</h2>
            </div>
            <div className="text-2xl font-black opacity-20">{currentSlide + 1} / {slides.length}</div>
          </header>

          <main className="flex-grow">
            {slides[currentSlide].content}
          </main>

          <footer className="mt-12 flex justify-between items-end border-t border-white/10 pt-6">
            <p className="text-xs opacity-50 uppercase tracking-widest">Growth Mastery Workshop | DFA - Art of Growth</p>
            <p className="text-xs font-bold">Kru Den Master Fa</p>
          </footer>
        </div>
      </div>

      {/* Navigation Controls */}
      <div className="no-print w-full flex flex-col items-center">
        <div className="flex space-x-4 mb-6">
          <button 
            onClick={prev} 
            disabled={currentSlide === 0}
            className="p-4 bg-white shadow-lg rounded-full hover:bg-gray-50 disabled:opacity-20 transition-all"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
          </button>
          
          <div className="bg-white px-8 py-4 shadow-lg rounded-full flex items-center space-x-2">
            {slides.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-8 bg-blue-600' : 'w-2 bg-gray-200'}`}
              />
            ))}
          </div>

          <button 
            onClick={next} 
            disabled={currentSlide === slides.length - 1}
            className="p-4 bg-white shadow-lg rounded-full hover:bg-gray-50 disabled:opacity-20 transition-all"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>

        {/* Thumbnails */}
        <div className="grid grid-cols-5 md:grid-cols-10 gap-2 w-full max-w-4xl px-4 overflow-auto pb-4">
          {slides.map((s, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`aspect-video rounded-md border-2 transition-all overflow-hidden text-[6px] p-1 font-bold ${i === currentSlide ? 'border-blue-600 scale-110 shadow-lg' : 'border-gray-200 opacity-60 hover:opacity-100'} ${themeClasses[s.theme]}`}
            >
              {s.title}
            </button>
          ))}
        </div>
      </div>

      {/* Hidden container for print - Renders all slides for PDF export */}
      <div className="hidden print:block w-full">
         {slides.map((s, i) => (
           <div key={i} className={`printable-slide page-break h-[210mm] w-[297mm] p-16 flex flex-col ${themeClasses[s.theme]}`}>
              <header className="flex justify-between items-start mb-12">
                <div>
                  <p className="text-xl font-black uppercase tracking-widest opacity-60">{s.section}</p>
                  <h2 className="text-5xl font-black tracking-tight">{s.title}</h2>
                </div>
                <div className="text-3xl font-black opacity-20">{i + 1} / {slides.length}</div>
              </header>
              <main className="flex-grow">
                {s.content}
              </main>
              <footer className="mt-12 flex justify-between items-end border-t border-white/10 pt-6">
                <p className="text-sm opacity-50 uppercase tracking-widest">Growth Mastery Workshop | DFA - Art of Growth</p>
                <p className="text-sm font-bold">Kru Den Master Fa</p>
              </footer>
           </div>
         ))}
      </div>
    </div>
  );
};
