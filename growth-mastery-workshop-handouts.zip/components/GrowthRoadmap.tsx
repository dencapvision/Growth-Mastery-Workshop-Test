
import React from 'react';
import { GrowthRoadmapState } from '../types';

interface Props {
  data: GrowthRoadmapState;
  onChange: (newData: Partial<GrowthRoadmapState>) => void;
  onGenerateAI: () => void;
  onGenerateRowAI: (index: number) => void;
  isGenerating?: boolean;
  rowGenerating?: number | null;
}

export const GrowthRoadmap: React.FC<Props> = ({ 
  data, onChange, onGenerateAI, onGenerateRowAI, isGenerating, rowGenerating 
}) => {
  const updatePlan = (index: number, field: string, value: any) => {
    const newPlans = [...data.plans];
    newPlans[index] = { ...newPlans[index], [field]: value };
    onChange({ plans: newPlans });
  };

  return (
    <div className="bg-white p-10 w-[210mm] h-[297mm] mx-auto shadow-2xl flex flex-col relative text-gray-800 printable-area border border-gray-100">
      <div className="border-b-4 border-emerald-600 pb-4 mb-8">
        <div className="flex justify-between items-start">
          <h1 className="text-2xl font-black text-emerald-800 tracking-tight uppercase">My Growth Roadmap: แผนที่การเติบโต</h1>
          <button onClick={onGenerateAI} disabled={isGenerating} className="no-print px-4 py-2 bg-emerald-600 text-white text-[10px] font-bold rounded-full hover:bg-emerald-700 disabled:opacity-50 transition-all shadow-sm">
            {isGenerating ? 'AI กำลังประมวลผล...' : '✨ AI แนะนำแผนทั้งหมด'}
          </button>
        </div>
        <div className="flex justify-between mt-6 text-xs font-bold text-gray-600 uppercase tracking-wider">
          <div className="flex items-center">NAME: <input className="ml-2 border-b border-gray-300 w-48 outline-none bg-transparent" value={data.name} onChange={e => onChange({ name: e.target.value })} /></div>
          <div className="flex items-center">TEAM: <input className="ml-2 border-b border-gray-300 w-48 outline-none bg-transparent" value={data.team} onChange={e => onChange({ team: e.target.value })} /></div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-50 p-5 rounded-2xl border border-gray-200">
          <h2 className="text-xs font-black text-gray-500 uppercase mb-4 border-b border-gray-200 pb-2 tracking-widest">Current Me (สำรวจตนเอง)</h2>
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-black text-emerald-700 uppercase">My Strengths (จุดแข็ง):</label>
              <textarea className="w-full text-xs bg-transparent border-b border-gray-200 outline-none h-16 resize-none mt-1 leading-relaxed" value={data.strengths.join('\n')} onChange={e => onChange({ strengths: e.target.value.split('\n') })} placeholder="- ความคิดสร้างสรรค์&#10;- การสื่อสาร" />
            </div>
            <div>
              <label className="text-[10px] font-black text-red-700 uppercase">My Gaps (สิ่งที่ต้องพัฒนา):</label>
              <textarea className="w-full text-xs bg-transparent border-b border-gray-200 outline-none h-16 resize-none mt-1 leading-relaxed" value={data.gaps.join('\n')} onChange={e => onChange({ gaps: e.target.value.split('\n') })} placeholder="- การบริหารเวลา&#10;- ทักษะภาษา" />
            </div>
          </div>
        </div>
        <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-100">
          <h2 className="text-xs font-black text-emerald-600 uppercase mb-4 border-b border-emerald-100 pb-2 tracking-widest">The Future (เป้าหมาย 90 วัน)</h2>
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-black text-emerald-800 uppercase">Main Goal (เป้าหมายสูงสุด):</label>
              <textarea className="w-full text-sm font-black bg-transparent border-b border-emerald-200 outline-none h-16 resize-none mt-1 leading-relaxed text-emerald-900" value={data.mainGoal} onChange={e => onChange({ mainGoal: e.target.value })} placeholder="เช่น ได้เลื่อนตำแหน่ง, เรียนจบโปรเจกต์..." />
            </div>
            <div>
              <label className="text-[10px] font-black text-emerald-800 uppercase">How it Feels (ความรู้สึกเมื่อสำเร็จ):</label>
              <input className="w-full text-xs bg-transparent border-b border-emerald-200 outline-none mt-1" value={data.feeling} onChange={e => onChange({ feeling: e.target.value })} placeholder="ภาคภูมิใจ, มั่นใจ..." />
            </div>
          </div>
        </div>
      </div>

      <div className="flex-grow">
        <h2 className="text-xs font-black bg-emerald-800 text-white px-5 py-2 inline-block rounded-t-xl uppercase tracking-widest">Action Plan (แผนลงมือทำ)</h2>
        <table className="w-full border-collapse border border-emerald-200 text-xs">
          <thead>
            <tr className="bg-emerald-100 text-emerald-900 font-black text-[10px] uppercase">
              <th className="border border-emerald-200 p-3 w-1/4">GOAL</th>
              <th className="border border-emerald-200 p-3 w-1/3">ACTION STEPS</th>
              <th className="border border-emerald-200 p-3">TIMELINE</th>
              <th className="border border-emerald-200 p-3">SUPPORT</th>
            </tr>
          </thead>
          <tbody>
            {data.plans.map((plan, idx) => (
              <tr key={idx}>
                <td className="border border-emerald-200 p-3 align-top font-bold text-emerald-900">
                  <textarea className="w-full bg-transparent outline-none resize-none font-bold" rows={3} value={plan.goal} onChange={e => updatePlan(idx, 'goal', e.target.value)} placeholder="เช่น ด้าน Mindset" />
                </td>
                <td className="border border-emerald-200 p-3 align-top group relative">
                  <textarea className="w-full bg-transparent outline-none resize-none text-[11px] leading-relaxed" rows={5} value={plan.steps.join('\n')} onChange={e => updatePlan(idx, 'steps', e.target.value.split('\n'))} placeholder="1. ...&#10;2. ..." />
                  <button onClick={() => onGenerateRowAI(idx)} disabled={rowGenerating === idx} className="no-print absolute bottom-1 right-1 opacity-0 group-hover:opacity-100 bg-emerald-100 text-emerald-700 text-[9px] px-2 py-1 rounded-md border border-emerald-200 transition-all font-black uppercase">
                    {rowGenerating === idx ? '...' : '✨ AI Suggest'}
                  </button>
                </td>
                <td className="border border-emerald-200 p-3 align-top">
                  <textarea className="w-full bg-transparent outline-none resize-none" rows={2} value={plan.timeline} onChange={e => updatePlan(idx, 'timeline', e.target.value)} placeholder="ทำเมื่อไหร่..." />
                </td>
                <td className="border border-emerald-200 p-3 align-top">
                  <textarea className="w-full bg-transparent outline-none resize-none" rows={2} value={plan.support} onChange={e => updatePlan(idx, 'support', e.target.value)} placeholder="ต้องการความช่วยเหลือจาก..." />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-10 bg-emerald-900 text-white p-6 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-800 opacity-30 rounded-full translate-x-10 -translate-y-10"></div>
        <h3 className="text-xs font-black text-emerald-400 mb-3 tracking-[0.2em] uppercase">My 1% Better Promise</h3>
        <p className="text-[12px] leading-relaxed italic mb-6">"ฉันสัญญาว่าจะลงมือทำวันละนิดเพื่อการเติบโตที่ยั่งยืน แม้เพียง 1% ก็ดีกว่าไม่ขยับเลย ฉันจะไม่หยุดเรียนรู้และจะก้าวข้ามขีดจำกัดของตัวเองในทุกๆ วัน"</p>
        <div className="grid grid-cols-2 gap-12 mt-6">
          <div>
            <div className="border-t border-emerald-600 pt-2 text-[10px] font-black opacity-60 uppercase tracking-widest">Your Signature</div>
          </div>
          <div>
            <div className="border-t border-emerald-600 pt-2 text-[10px] font-black opacity-60 uppercase tracking-widest">Date</div>
          </div>
        </div>
      </div>
      
      <div className="text-center mt-6 text-[9px] text-gray-400 font-bold uppercase tracking-[0.3em]">Growth Mastery Workshop | Kruden Masterfa | DFA - Art of Growth</div>
    </div>
  );
};
