
import React from 'react';
import { RadarChart } from './RadarChart';
import { WheelData } from '../types';

interface Props {
  data: WheelData;
  onChange: (newData: Partial<WheelData>) => void;
  reflections: {
    shape: string;
    missing: string;
    commitment: string;
  };
  onReflectionChange: (key: string, val: string) => void;
}

const labels = [
  'การงาน', 'การเงิน', 'สุขภาพ', 'ครอบครัว',
  'ความสัมพันธ์', 'พัฒนาตนเอง', 'การพักผ่อน', 'จิตวิญญาณ'
];

export const WheelOfLife: React.FC<Props> = ({ data, onChange, reflections, onReflectionChange }) => {
  const scores = [
    data.career, data.finances, data.health, data.family,
    data.relationships, data.growth, data.fun, data.contribution
  ];

  const handleScoreChange = (key: keyof WheelData, val: string) => {
    const num = Math.min(10, Math.max(0, parseInt(val) || 0));
    onChange({ [key]: num });
  };

  return (
    <div className="bg-white p-8 w-[210mm] h-[297mm] mx-auto shadow-lg flex flex-col relative overflow-hidden text-gray-800 printable-area">
      {/* Header Decoration */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -z-0 no-print"></div>
      
      {/* Head */}
      <div className="border-b-2 border-blue-600 pb-4 mb-6 z-10">
        <h1 className="text-3xl font-bold text-blue-800 tracking-tight">THE WHEEL OF HARMONY: วงล้อแห่งความสมดุล</h1>
        <div className="flex justify-between mt-4 text-sm font-medium">
          <div className="flex items-center">
            Name: <input type="text" placeholder="..........................................." className="ml-2 border-b border-transparent focus:border-blue-300 outline-none w-64 bg-transparent" />
          </div>
          <div className="flex items-center">
            Date: <input type="text" placeholder=".............................." className="ml-2 border-b border-transparent focus:border-blue-300 outline-none w-32 bg-transparent text-right" />
          </div>
        </div>
        <p className="italic text-gray-500 mt-2 text-xs">"Life is a bicycle. To keep your balance, you must keep moving."</p>
      </div>

      <div className="grid grid-cols-2 gap-8 flex-grow">
        {/* Left Side: Assessment */}
        <div className="flex flex-col space-y-4">
          <div>
            <h2 className="text-lg font-bold bg-blue-600 text-white px-3 py-1 inline-block rounded-md mb-2">PART 1: ASSESSMENT (สำรวจตนเอง)</h2>
            <p className="text-xs text-gray-600 mb-3 leading-tight">คำชี้แจง: ให้คะแนนความพึงพอใจในแต่ละด้าน (0 = ไม่พอใจเลย, 10 = พอใจมากที่สุด) แล้วลากเส้นเชื่อมจุดเข้าด้วยกัน</p>
            
            <ul className="space-y-2 text-sm">
              {[
                { key: 'career', label: '1. การงาน (Career & Passion)', desc: 'ความสุขในงาน, ความก้าวหน้า' },
                { key: 'finances', label: '2. การเงิน (Finances)', desc: 'รายรับ-รายจ่าย, เงินออม' },
                { key: 'health', label: '3. สุขภาพ (Health & Vitality)', desc: 'ความแข็งแรง, การนอน, พลังงาน' },
                { key: 'family', label: '4. ครอบครัว (Family)', desc: 'เวลาคุณภาพ, ความสัมพันธ์' },
                { key: 'relationships', label: '5. ความรัก/ความสัมพันธ์ (Relationships)', desc: 'คู่รัก, เพื่อนสนิท, สังคม' },
                { key: 'growth', label: '6. การพัฒนาตนเอง (Personal Growth)', desc: 'การเรียนรู้ทักษะใหม่, Mindset' },
                { key: 'fun', label: '7. การพักผ่อน (Fun & Recreation)', desc: 'งานอดิเรก, การท่องเที่ยว' },
                { key: 'contribution', label: '8. จิตวิญญาณ/การแบ่งปัน (Spiritual)', desc: 'ความสงบใจ, การเป็นผู้ให้' },
              ].map((item) => (
                <li key={item.key}>
                  <div className="flex justify-between items-center">
                    <strong className="text-xs">{item.label}</strong>
                    <div className="flex items-center">
                      <input 
                        type="number" 
                        min="0" max="10" 
                        value={data[item.key as keyof WheelData] || ''} 
                        onChange={(e) => handleScoreChange(item.key as keyof WheelData, e.target.value)}
                        className="w-10 text-center border-b border-gray-300 focus:border-blue-500 outline-none text-sm font-bold bg-blue-50/50 rounded no-appearance-inner"
                      />
                      <span className="ml-1">/10</span>
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-500">-{item.desc}</p>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-4 mt-auto">
             <RadarChart data={scores} labels={labels} size={250} />
          </div>
        </div>

        {/* Right Side: Reflection */}
        <div className="flex flex-col space-y-6">
          <h2 className="text-lg font-bold bg-orange-500 text-white px-3 py-1 inline-block rounded-md self-start">PART 2: DEEP REFLECTION (ตกผลึกความคิด)</h2>
          
          <div className="space-y-1">
            <h3 className="font-bold text-sm">1. The Shape:</h3>
            <p className="text-xs text-gray-600 mb-1">ลองมองดูรูปร่างวงล้อของคุณ... ถ้าเปรียบชีวิตเหมือนรถยนต์ วงล้อรูปร่างนี้จะพาคุณวิ่งไปข้างหน้าได้ราบรื่นแค่ไหน?</p>
            <textarea 
              value={reflections.shape}
              onChange={(e) => onReflectionChange('shape', e.target.value)}
              placeholder="บันทึกความคิดเห็นที่นี่..."
              className="w-full h-24 p-2 text-sm border-b border-gray-200 focus:border-orange-300 outline-none resize-none bg-orange-50/10"
            />
          </div>

          <div className="space-y-1">
            <h3 className="font-bold text-sm">2. The Missing Piece:</h3>
            <p className="text-xs text-gray-600 mb-1">ด้านใดที่คุณ "ละเลย" มานานที่สุด? และถ้าคุณพัฒนาด้านนี้ขึ้นมาได้ จะส่งผลดีต่อด้านอื่นๆ อย่างไร?</p>
            <textarea 
              value={reflections.missing}
              onChange={(e) => onReflectionChange('missing', e.target.value)}
              placeholder="บันทึกความคิดเห็นที่นี่..."
              className="w-full h-24 p-2 text-sm border-b border-gray-200 focus:border-orange-300 outline-none resize-none bg-orange-50/10"
            />
          </div>

          <div className="space-y-1 p-4 bg-blue-50 rounded-lg border border-blue-100">
            <h3 className="font-bold text-sm text-blue-800">3. The Commitment:</h3>
            <p className="text-xs text-blue-600 mb-2">เพื่อให้วงล้อสมดุลขึ้น "1 สิ่งเล็กๆ" ที่ฉันจะเริ่มทำตั้งแต่วันพรุ่งนี้ คือ...</p>
            <textarea 
              value={reflections.commitment}
              onChange={(e) => onReflectionChange('commitment', e.target.value)}
              placeholder="ฉะนจะเริ่มทำ..."
              className="w-full h-20 p-2 text-sm font-bold text-blue-900 border-b border-blue-200 focus:border-blue-400 outline-none resize-none bg-transparent"
            />
          </div>

          {/* Artistic Footer */}
          <div className="mt-auto pt-6 text-center">
            <div className="h-0.5 bg-gray-100 w-full mb-2"></div>
            <p className="text-[10px] text-gray-400">Created by Kruden Masterfa | Line OA: @denmasterfa</p>
          </div>
        </div>
      </div>
    </div>
  );
};
